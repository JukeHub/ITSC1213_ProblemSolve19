Add the following details to your README file using Markdown language:

    Full name: Julian Dominguez

    UNCC email: jdomin14@charlotte.edu

    UNCC ID number: 801450236

    GitHub user name: JukeHub

    The name of this activity: Problem Solve 19 and 20

    RectangleTest.java takes user input (width and height), caulculates the area, and uses if statements to compare it to what the area should be. 

    Circle.java contains two constructors, and methods that allow you to get the radius, color, and area of a circle.

    GitHub URL for Problem Solve 19 and 20: https://github.com/JukeHub/ITSC1213_ProblemSolve19

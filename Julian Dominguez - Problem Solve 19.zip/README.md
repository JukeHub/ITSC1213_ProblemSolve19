Add the following details to your README file using Markdown language:

    Full name: Julian Dominguez

    UNCC email: jdomin14@charlotte.edu

    UNCC ID number: 801450236

    GitHub user name: JukeHub

    The name of this activity

    An explanation of the RectangleTest.java program, in plain English. This should be a complete and detailed explanation of the code and what it does.

    An explanation of the Circle.java program, in plain English. This should be a complete and detailed explanation of the code and what it does.

    The URL for your private project in GitHub.
